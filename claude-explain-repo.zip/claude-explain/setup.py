"""Legacy setup.py — project config lives in pyproject.toml."""
from setuptools import setup

if __name__ == "__main__":
    setup()
