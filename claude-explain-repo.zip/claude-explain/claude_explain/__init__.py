"""claude-explain — Explain any code snippet with Claude AI."""

__version__ = "1.0.0"
